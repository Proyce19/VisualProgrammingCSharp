﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
   public class PolicemanBoss
    {

        public Point Center { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public bool isDead { get; set; }
        public int power { get; set; }
        public int damage { get; set; }

        public int speed { get; set; }

        public bool hascolided { get; set; }

        public Image Look { get; set; }



        public PolicemanBoss()
        {
            width = 50;
            height = 79;
            speed = 3;
            damage = 15;
            power = 20;
            isDead = false;
            hascolided = false;
            Look = Properties.Resources.swat;


        }
        public void Draw(Graphics g)
        {
            g.DrawImage(Look, Center);
        }

        public void Move(Point p)
        {
            if (Center.X > p.X && Center.Y > p.Y)
            {
                Center = new Point(Center.X - speed, Center.Y - speed);


            }
            else if (Center.X > p.X && Center.Y < p.Y)
            {
                Center = new Point(Center.X - speed, Center.Y + speed);


            }
            else if (Center.X < p.X && Center.Y > p.Y)
            {
                Center = new Point(Center.X + speed, Center.Y - speed);


            }
            else if (Center.X < p.X && Center.Y < p.Y)
            {
                Center = new Point(Center.X + speed, Center.Y + speed);


            }
            else
            {
                hascolided = true;


            }




        }
        public bool hasColidedWithBullet(Point p)
        {

            return ((Center.X - p.X) * (Center.X - p.X) + (Center.Y - p.Y) * (Center.Y - p.Y)) <= width * height;
        }
        public bool PowerZero()
        {
            return power <= 0;
        }



    }
}
