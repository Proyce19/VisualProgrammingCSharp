﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class LionsDoc
    {
        public List<Lion> lionsList { get; set; }
        public int totalKills { get; set; }
        public LionsDoc()
        {
           lionsList= new List<Lion>();
            totalKills = 0;
        }

        public void AddLion(Lion z)
        {
            lionsList.Add(z);
        }
        public void Move(Point p)
        {

            foreach (Lion z in lionsList)
            {
                z.Move(p);
            }
        }

        public void Draw(Graphics g)
        {

            foreach (Lion z in lionsList)
            {
                z.Draw(g);
            }
        }

        public void IncreasePower()
        {
            foreach (Lion z in lionsList)
            {
                if (z.hascolided == true)
                {

                    z.power++;

                }
            }


        }
        public void CheckCollisonsWithBullets(Point p, int damage)
        {
            foreach (Lion z in lionsList)
            {
                if (z.hasColidedWithBullet(p) == true)
                {
                    z.power -= damage;
                    if (z.power <= 0)
                    {
                        z.isDead = true;
                    }
                }
            }

        }
        public void PowerZero()
        {
            foreach (Lion z in lionsList)
            {
                if (z.PowerZero() == true)
                {
                    totalKills += 2;
                    z.isDead = true;
                }
            }
        }

        public void Delete()
        {

            for (int i = lionsList.Count - 1; i >= 0; i--)
            {
                if (lionsList[i].isDead == true)
                {
                    lionsList.RemoveAt(i);
                }
            }
        }




    }
}
