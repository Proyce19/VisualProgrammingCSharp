﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProShooter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DoctorNormanForm normanForm { get; set; }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            normanForm = new DoctorNormanForm();
            normanForm.ShowDialog();
        }

        LuigiForm luigiForm { get; set; }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            luigiForm = new LuigiForm();
            luigiForm.Show();
        }
        RangerForm rangerForm { get; set; }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            rangerForm = new RangerForm();
            rangerForm.Show();

        }
        Informations informations { get; set; }
        private void button1_Click(object sender, EventArgs e)
        {
            informations = new Informations();
            informations.Show();
        }
    }
}
