﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class ZombieBossDoc
    {
        public List<ZombieBoss> zombieBosses { get; set; }
        public int totalKills { get; set; }
        public ZombieBossDoc()
        {
            zombieBosses = new List<ZombieBoss>();
            totalKills = 0;
        }

        public void AddZombieBoss(ZombieBoss z)
        {
            zombieBosses.Add(z);
        }
        public void Move(Point p)
        {

            foreach (ZombieBoss z in zombieBosses)
            {
                z.Move(p);
            }
        }

        public void Draw(Graphics g)
        {

            foreach (ZombieBoss z in zombieBosses)
            {
                z.Draw(g);
            }
        }

        public void IncreasePower()
        {
            foreach (ZombieBoss z in zombieBosses)
            {
                if (z.hascolided == true)
                {

                    z.power++;

                }
            }


        }
        public void CheckCollisonsWithBullets(Point p, int damage) {
            foreach (ZombieBoss z in zombieBosses) {
                if (z.hasColidedWithBullet(p) == true) {
                    z.power -= damage;
                    if (z.power <= 0) {
                        totalKills += 2;
                        z.isDead = true;
                    }
                }
            }

        }
        public void PowerZero() {
            foreach (ZombieBoss z in zombieBosses) {
                if (z.PowerZero() == true) {
                    z.isDead=true;
                }
            }
        }

        public void Delete() {

            for (int i = zombieBosses.Count - 1; i >= 0; i--) {
                if (zombieBosses[i].isDead == true) {
                    zombieBosses.RemoveAt(i);
                }
            }
        }
    }
}
