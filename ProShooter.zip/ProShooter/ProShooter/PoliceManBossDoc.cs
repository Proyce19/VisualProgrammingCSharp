﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
   public class PoliceManBossDoc
    {
        public List<PolicemanBoss> policeBosses { get; set; }
        public int totalKills { get; set; }
        public PoliceManBossDoc()
        {
            policeBosses = new List<PolicemanBoss>();
            totalKills = 0;
        }

        public void AddPoliceBoss(PolicemanBoss z)
        {
            policeBosses.Add(z);
        }
        public void Move(Point p)
        {

            foreach (PolicemanBoss z in policeBosses)
            {
                z.Move(p);
            }
        }

        public void Draw(Graphics g)
        {

            foreach (PolicemanBoss z in policeBosses)
            {
                z.Draw(g);
            }
        }

        public void IncreasePower()
        {
            foreach (PolicemanBoss z in policeBosses)
            {
                if (z.hascolided == true)
                {

                    z.power++;

                }
            }


        }
        public void CheckCollisonsWithBullets(Point p, int damage)
        {
            foreach (PolicemanBoss z in policeBosses)
            {
                if (z.hasColidedWithBullet(p) == true)
                {
                    z.power -= damage;
                    if (z.power <= 0)
                    {
                        z.isDead = true;
                    }
                }
            }

        }
        public void PowerZero()
        {
            foreach (PolicemanBoss z in policeBosses)
            {
                if (z.PowerZero() == true)
                {
                    totalKills += 2;
                    z.isDead = true;
                }
            }
        }

        public void Delete()
        {

            for (int i = policeBosses.Count - 1; i >= 0; i--)
            {
                if (policeBosses[i].isDead == true)
                {
                    policeBosses.RemoveAt(i);
                }
            }
        }


    }
}
