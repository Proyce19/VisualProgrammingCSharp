﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProShooter
{
    public partial class DoctorNormanForm : Form
    {
        Zombie zombie;
        ZombieBoss zombieBoss;
        DoctorNorman doctorNorman;
        Timer timerZombie;
        Timer timerZombieBoss;
        Random random;
        ZombieBossDoc docZB;
        ZombieDoc doc;
        Timer moveZombie;
        Timer moveZB;
        Timer timerDoctor;
        Rectangle borders;
        Bullet bullet;
        BulletsDoc bulletsDoc;
        Timer bulletTimer;
       
        public DoctorNormanForm()
        {
            InitializeComponent();
            DoubleBuffered = true;
            newDoc();
        }

        private void newDoc() {
          
            borders = new Rectangle(0,0,Width, Height);
            doc = new ZombieDoc();
            docZB = new ZombieBossDoc();
            zombie = null;
            zombieBoss = null;
            random = new Random();
            doctorNorman = new DoctorNorman();
            doctorNorman.Center = new Point(random.Next(15, Width / 4),random.Next(5,Height-15));
            doctorNorman.borders = borders;
            bullet = null;
            bulletsDoc = new BulletsDoc();
            timerZombie = new Timer();
            timerZombie.Interval = 3000;
            timerZombie.Tick += new EventHandler(timerZombie_Tick);
            timerZombie.Start();
            timerZombieBoss = new Timer();
            timerZombieBoss.Interval = 6000;
            timerZombieBoss.Tick += new EventHandler(timerZombieBoss_Tick);
            timerZombieBoss.Start();
            moveZombie = new Timer();
            moveZombie.Interval = 150;
            moveZombie.Tick += new EventHandler(moveZombie_Tick);
            moveZombie.Start();
            moveZB = new Timer();
            moveZB.Interval = 150;
            moveZB.Tick += new EventHandler(moveZB_Tick);
            moveZB.Start();
            timerDoctor = new Timer();
            timerDoctor.Interval = 100;
            timerDoctor.Tick += new EventHandler(timerDoctor_Tick);
            
            timerDoctor.Start();
            bulletTimer = new Timer();
            bulletTimer.Interval = 100;
            bulletTimer.Tick += new EventHandler(bulletTimer_Tick);
            bulletTimer.Start();
        }
        private void bulletTimer_Tick(object sender, EventArgs e) {
            bulletsDoc.Move();
             foreach (Zombie z in doc.zombieList)
            {
                bulletsDoc.CheckCollisions(z.Center);
               

            }
            foreach (ZombieBoss z in docZB.zombieBosses)
            {
                bulletsDoc.CheckCollisions(z.Center);


            }

            bulletsDoc.Delete();
            Invalidate(true);
        }
        private void timerDoctor_Tick(object sender, EventArgs e)
        {
          
            if (doctorNorman.power <= 15)
            {
                pictureBox1.Image = Properties.Resources._3lives;
            }
            if (doctorNorman.power <= 10)
            {
                pictureBox1.Image = Properties.Resources._2lives;
            }
            if (doctorNorman.power <= 5)
            {
                pictureBox1.Image = Properties.Resources._1life;
            }
            if (doctorNorman.power <= 0)
            {
                pictureBox1.Image = null;
            }
            foreach (Zombie z in doc.zombieList)
            {
                if (doctorNorman.HasColided(z.Center))
                {
                    doctorNorman.power -= z.power;
                }

            }
            foreach (ZombieBoss z in docZB.zombieBosses) {
                if (doctorNorman.HasColided(z.Center)) {
                    doctorNorman.power = 0;
                }
            }
           

            if (doctorNorman.PowerZero() == true) {
                Application.Exit();
            }
            Invalidate(true);
        }
        private void AskNewGame() {
            int score = doc.totalKills + docZB.totalKills;
            DialogResult dialog = MessageBox.Show("Doctor Norman is dead. Your score is: " + score.ToString(), "The game is over", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (dialog == DialogResult.Yes) {
                newDoc();
            }
            if (dialog == DialogResult.No) {
                Application.Exit();
            }
        }
        private void timerZombie_Tick(object sender, EventArgs e) {
            zombie = new Zombie();
            zombie.Center = new Point(random.Next(Width - 100, Width - 20), random.Next(30, Height - 30));
            zombie.borders = borders;
            doc.AddZombie(zombie);
            Invalidate(true);
        }
        private void timerZombieBoss_Tick(object sender, EventArgs e) {
            zombieBoss = new ZombieBoss();
            zombieBoss.Center = new Point(random.Next(Width - 100, Width - 20), random.Next(30, Height - 30));
            docZB.AddZombieBoss(zombieBoss);
            Invalidate(true);
        }
        private void moveZombie_Tick(object sender, EventArgs e) {
            doc.Move();
            doc.CheckCrosses();
            doc.CheckColisions(doctorNorman.Center);
            foreach (Bullet b in bulletsDoc.Bullets)
            {
                doc.CheckCollisionsWithBullets(b.Center,doctorNorman.damage);
            }
            doc.DeleteZombie();
            Invalidate(true);
        }

        public void moveZB_Tick(object sender, EventArgs e) {
            docZB.Move(doctorNorman.Center);
            docZB.IncreasePower();
            foreach (Bullet b in bulletsDoc.Bullets)
            {
               docZB.CheckCollisonsWithBullets(b.Center,doctorNorman.damage);
            }
            docZB.PowerZero();
            docZB.Delete();
            Invalidate(true);

        }

        private void DoctorNormanForm_Paint(object sender, PaintEventArgs e)
        {
            doctorNorman.Draw(e.Graphics);
            if (zombie != null) {
                zombie.Draw(e.Graphics);
            }
            if (zombieBoss != null) {
                zombieBoss.Draw(e.Graphics);
            }
            if (bullet != null) {
                bullet.Draw(e.Graphics);
            }
            bulletsDoc.Draw(e.Graphics);
            doc.Draw(e.Graphics);
            docZB.Draw(e.Graphics);
        }

        private void DoctorNormanForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W || e.KeyCode == Keys.Up)
            {
                doctorNorman.direction = DoctorNorman.TYPE.Up;
                doctorNorman.Move();

            }
            if (e.KeyCode == Keys.S || e.KeyCode == Keys.Down)
            {
                doctorNorman.direction = DoctorNorman.TYPE.Down;
                doctorNorman.Move();
            }
            if (e.KeyCode == Keys.A || e.KeyCode == Keys.Left)
            {
                doctorNorman.direction = DoctorNorman.TYPE.Left;
                doctorNorman.Move();
            }
            if (e.KeyCode == Keys.D || e.KeyCode == Keys.Right)
            {
                doctorNorman.direction = DoctorNorman.TYPE.Right;
                doctorNorman.Move();
            }
            if (e.KeyCode == Keys.Space) {
                bullet = new Bullet();
                if (doctorNorman.direction == DoctorNorman.TYPE.Left) {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (doctorNorman.direction == DoctorNorman.TYPE.Right)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (doctorNorman.direction == DoctorNorman.TYPE.Up)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                if (doctorNorman.direction == DoctorNorman.TYPE.Down)
                {
                    bullet.direction = Bullet.TYPE.Right;
                }
                bullet.Center = doctorNorman.Center;
                bullet.borders = borders;
                bulletsDoc.AddBullet(bullet);
            }
            Invalidate(true);
        }

        private void DoctorNormanForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            AskNewGame();
            Invalidate(true);
        }

        private void DoctorNormanForm_Resize(object sender, EventArgs e)
        {
            borders = new Rectangle(0, 0, Width, Height);
            foreach (Bullet b in bulletsDoc.Bullets) {
                b.borders = borders;
            }
            foreach (Zombie z in doc.zombieList) {
                z.borders = borders;
            }
            doctorNorman.borders = borders;
            Invalidate(true);
        }

        private void DoctorNormanForm_Load(object sender, EventArgs e)
        {
          
          
            
        }

        private void statusStrip1_Paint(object sender, PaintEventArgs e)
        {
            int score = doc.totalKills + docZB.totalKills;
            int force = doc.zombieList.Count + docZB.zombieBosses.Count;
            toolStripStatusLabel1.Text = "Score: " + score.ToString() + ". Zombies: " + force.ToString();
        }

       
    }
}
