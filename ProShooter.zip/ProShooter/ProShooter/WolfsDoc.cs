﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProShooter
{
    public class WolfsDoc
    {
        public List<Wolf> wolfsList { get; set; }
        public int globalCrossesCounter { get; set; }
        public int totalKills { get; set; }
        public int globalZombiePower { get; set; }
        public WolfsDoc()
        {
            wolfsList = new List<Wolf>();
            globalCrossesCounter = 0;
            totalKills = 0;

        }

        public void AddWolf(Wolf z)
        {
            wolfsList.Add(z);

        }
        public void Draw(Graphics g)
        {

            foreach (Wolf z in wolfsList)
            {
                z.Draw(g);
            }
        }
        public void Move()
        {

            foreach (Wolf z in wolfsList)
            {
                z.Move();
            }
        }

        public void CheckCrosses()
        {
            foreach (Wolf z in wolfsList)
            {
                globalCrossesCounter += z.countCrosses;
            }
        }

        public void CheckColisions(Point p)
        {
            foreach (Wolf z in wolfsList)
            {
                if (z.HasColided(p) == true)
                {
                    globalZombiePower += z.power;
                    z.power = 0;
                    z.isDead = true;
                }
            }


        }
        public void CheckCollisionsWithBullets(Point p, int damage)
        {
            foreach (Wolf z in wolfsList)
            {
                if (z.HasColided(p) == true)
                {

                    z.power -= damage;
                    if (z.power <= 0)
                    {
                        totalKills++;
                        z.isDead = true;
                    }
                }
            }
        }

        public void DeleteZombie()
        {
            for (int i = wolfsList.Count - 1; i >= 0; i--)
            {
                if (wolfsList[i].isDead == true)
                {
                    wolfsList.RemoveAt(i);
                }

            }

        }



    }
}
